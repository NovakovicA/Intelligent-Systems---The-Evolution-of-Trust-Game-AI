package rs.ac.bg.etf.players;

import java.util.ArrayList;
import java.util.List;

import rs.ac.bg.etf.players.Player.Move;

public class Nemesis extends Player {
	private List<Move> myMoves;
	
	private int numOfRounds=0;
	private int numOfRounds2=0;
	private boolean firstGame=true;
	
	//Settings
	private boolean beCompetitive=false;
	private int nCompRoundsMin=5;
	private int nCompRoundsMax=20;
	private int stopPlaying;
	
	private int genRandomNumber(int min, int max) {
		return (int)((Math.random() * (max-min+1))+min);
	}
	
	public Nemesis() {
		this.myMoves = new ArrayList<Move>();
		stopPlaying=genRandomNumber(nCompRoundsMin,nCompRoundsMax);
	}
	
	
	private Move analyzeUnknownOpponent() {
		int ind=0;
		int C0=0,C1=0,C2=0;
		double P0=0,P1=0,P2=0;
		int L[]={1,1,1};
		for(Move e:this.opponentMoves) {
			if(e.ordinal()==0) C0++;
			else if(e.ordinal()==1) C1++;
			else C2++;
			
			if(ind>this.opponentMoves.size()-4) L[this.opponentMoves.size()-1-ind]=e.ordinal();
			ind++;
		}
		P0=C0/(C0+C1+C2);
		P1=C1/(C0+C1+C2);
		P2=C2/(C0+C1+C2);
		
		if (C0>1 && P0>0.1) return Move.DONTPUTCOINS;

		else if (L[0]+L[1]+L[2]>4 && P1<0.2) return Move.DONTPUTCOINS;
		
		else if (L[0]+L[1]+L[2]>4) return Move.PUT2COINS;
		
		else if (L[0]+L[1]+L[2]==4 && (P0<0.1||C0<3)) return Move.PUT2COINS;
		
		else if ((L[0]==0 || L[1]==0 || L[2]==0) && (L[0]+L[1]+L[2]==3)) return Move.PUT1COIN;
		
		
		else return Move.DONTPUTCOINS;
	}
	
	private boolean checkGhost() {
		boolean ret=false; int ind=0;
		
		if(this.opponentMoves.get(0)==Move.PUT2COINS && this.opponentMoves.get(1)==Move.PUT1COIN) ret=true;
		else return false;
		
		for(Move e:this.opponentMoves) {
			if(ind>1 && e!=Move.PUT2COINS) return false;
			ind++;
		}
		return ret;
	}
	
	private boolean checkStinger() {
		boolean ret=true;
		for(Move e:this.opponentMoves) {
			if(e!=Move.DONTPUTCOINS) {ret=false; break;}
		}
		return ret;
	}

	private boolean checkGoodie() {
		boolean ret=true;
		for(Move e:this.opponentMoves) {
			if(e!=Move.PUT2COINS) {ret=false; break;}
		}
		return ret;
	}
	
	private boolean checkCopycat() {
		if(this.opponentMoves.get(0)!=Move.PUT1COIN) return false;
		boolean ret=true; boolean first=true; int ind=0;
		for(Move e:this.opponentMoves) {
			if(!first) {if(e!=this.myMoves.get(ind-1)) {ret=false; break;}}
			else first=false;
			ind++;
		}
		return ret;
	}
	
	
	private boolean checkForgiver() {
		if(this.opponentMoves.get(0)!=Move.PUT1COIN)  return false;
		boolean ret=true; boolean first=true; int forMax=1; int forgivings=forMax; int ind=0;
		for(Move e:this.opponentMoves) {
			if(!first) {
				if(e!=this.myMoves.get(ind-1) && this.myMoves.get(ind-1)==Move.DONTPUTCOINS &&
					(forgivings>0) && e==this.opponentMoves.get(ind-1)) forgivings--;
				else if (e==this.myMoves.get(ind-1)) forgivings=forMax;
				else {ret=false; break;}
			}
			else first=false;
			ind++;
		}
		return ret;
	}
	
	private boolean checkAvenger() {
		if(this.opponentMoves.get(0)!=Move.PUT2COINS) return false;
		boolean ret=true; Move min=Move.PUT2COINS; int ind=0;
		for(Move e:this.myMoves) {
			if(ind+1<this.myMoves.size()) {
			if(e.ordinal()<min.ordinal()) min=e;
			if(this.opponentMoves.get(ind+1)!=min) {ret=false; break;}
			ind++;
			}
		}
		return ret;
	}
	
	
	
	private int opponentProfile() {
		// -1 - nepoznat
		//  0 - goody
		//  1 - stinger
		//  2 - copycat
		//  3 - forgiver
		//  4 - avenger
		if(this.opponentMoves.size()<1) return -1;
		else if(checkGhost()) return 5;
		else if(checkGoodie()) return 0;
		else if(checkStinger()) return 1;
		else if(checkCopycat()) return 2;
		else if(checkForgiver()) return 3;
		else if(checkAvenger()) return 4;
		else return -1;
	}
	
	
	
	
	public void resetPlayerState() {
	 super.resetPlayerState();
	 this.myMoves.clear();
	 firstGame=false;
	 numOfRounds2=0;
	 stopPlaying=genRandomNumber((numOfRounds*2)/3,numOfRounds-1);
	 //System.out.println("============================");
	 }

	@Override
	public Move getNextMove() {
		Move ret=Move.PUT2COINS;
		int opponentType=-2;
		if (this.myMoves.size()>=2) opponentType=opponentProfile();
		
		
		if(opponentType==0) ret=Move.DONTPUTCOINS;
		else if(opponentType==1) ret=Move.DONTPUTCOINS;
		else if((opponentType==2 || opponentType==3) & this.myMoves.size()==2) ret=Move.DONTPUTCOINS;
		else if(opponentType==2) ret=Move.PUT2COINS;
		else if(opponentType==3) {
			if(firstGame) {if(numOfRounds%1==0) ret=Move.PUT2COINS; else ret=Move.DONTPUTCOINS;}
			else {if(numOfRounds2%1==0) ret=Move.PUT2COINS; else ret=Move.DONTPUTCOINS;}
		}
		else if(opponentType==4) ret=Move.DONTPUTCOINS;
		else if(opponentType==5) ret=Move.PUT2COINS;
		else if(opponentType==-1) ret=Move.DONTPUTCOINS;
		else if(opponentType==-2 && this.myMoves.size()==1 && this.opponentMoves.get(0)==Move.DONTPUTCOINS) ret=Move.DONTPUTCOINS;
		else if(opponentType==-2 && this.myMoves.size()==1) ret=Move.PUT1COIN;
		
		
		if(firstGame) numOfRounds++;
		else {
			numOfRounds2++;
			if(numOfRounds2==numOfRounds) ret=Move.DONTPUTCOINS;
		}
		
		if(!firstGame && beCompetitive && stopPlaying<=0 && (opponentType==5 || opponentType==-1)) ret=Move.DONTPUTCOINS;
		else if(!firstGame && beCompetitive) stopPlaying--;
		
		//System.out.println("Played " + ret.ordinal() + " type " + opponentType + " enemy moves: " + this.opponentMoves); 
		this.myMoves.add(ret); 
		return ret;
	}

}
