package rs.ac.bg.etf.players;

import java.util.ArrayList;
import java.util.List;

import rs.ac.bg.etf.players.Player.Move;

public class TestPlayer extends Player {
	private List<Move> potezi;
	private int ind=0;
	
	public TestPlayer() {
		potezi = new ArrayList<Move>();
		potezi.add(Move.PUT2COINS);
		potezi.add(Move.PUT1COIN);
		potezi.add(Move.DONTPUTCOINS);
	}

	public void resetPlayerState() {
		 super.resetPlayerState();
		 ind=0;
		 //System.out.println("============================");
		 }
	
    public Move getNextMove() {
    	Move ret=Move.DONTPUTCOINS;
    	ret=potezi.get(ind);
    	ind++;
    	if(ind>potezi.size()-1) ind=0;
    	
    	//System.out.println("-Played " + ret.ordinal() + ", Enemy played: " + this.opponentMoves); 
        return ret;
    }
}
